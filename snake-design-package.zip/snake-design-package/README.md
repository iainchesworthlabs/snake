# Snake: design and PRD package

Everything needed to build v1 of Snake: the product requirements, the Toybox Pixel visual design, and machine-readable design tokens.

## What's inside

```
PRD.md                     Product requirements (start here)
prd/
  screen-flow.png          Screen flow and game states diagram
  screen-flow.mmd          Same diagram as Mermaid source
design/
  index.html               Gallery of every screen; open in a browser, works offline
  tokens.json              Colours, type, sizes, shadows, board and motion values
  screenshots/             PNG of each screen at 2x
  screens/                 Standalone, clickable HTML version of each screen
  source/                  Original design canvas files (.dc.html) and layout (canvas.json)
  fonts/                   Pixelify Sans, Tilt Neon and Silkscreen with their licences
```

## Viewing the design

Open `design/index.html` in any modern browser. Each card links to a working version of the screen: mode select, pause settings, name entry and leaderboard tabs respond to clicks, and the buttons link the screens into a simple prototype (Play, Pause, Resume, Quit, Play again, Menu).

The chosen direction is Toybox Pixel. The Vector Glow and Amber LCD screens are earlier explorations kept for reference only.

## Handing over to Claude Code

1. Copy this folder into the repo, for example under `docs/design/`.
2. Point Claude Code at `PRD.md` first, then `design/tokens.json` and `design/screenshots/`.
3. Treat the screenshots and tokens as the visual spec. The files in `design/source` and `design/screens` are design mockups, not production code; use them for exact spacing and sizes, not as an implementation to copy.

A starting prompt:

> Read docs/design/PRD.md and docs/design/design/tokens.json, and look at the screenshots in docs/design/design/screenshots. Then propose an implementation plan for v1 that fits this repo, starting with the deterministic simulation core and its tests, before writing any code.

## Live versions

- PRD as an editable Claude Doc: https://claude.ai/artifact/PzsZQrfotZZ3abSvSMq1Rg
- Design canvas: https://claude.ai/artifact/1NG2i4Vwo4wZoC6xkmXYGK

This package is a snapshot from 23 October 2026. If either live version changes, regenerate the package.

## Open items

- The ESP layout assumes a 1024 x 600 landscape touch panel. Confirm the real display.
- The Settings screen is not yet designed.
- All tuning values (speeds, tilt angles, combo window, unlock scores) are starting defaults for playtesting.
